public class Main {
    public static void main(String[] args) {
        // Crear objetos sin datos quemados
        Profesor profesor1 = new Profesor("Juan Pérez", "1-1111-1111", "Lunes 7am-11am, Miércoles 1pm-5pm", "Ciencias de la Computación");
        Profesor profesor2 = new Profesor("María Rodríguez", "2-2222-2222", "Martes 8am-12pm, Jueves 2pm-6pm", "Ciencias de la Computación");

        Departamento departamento1 = new Departamento("Ciencias de la Computación");
        Departamento departamento2 = new Departamento("Matemática");

        AsignaturaTeorica asignatura1 = new AsignaturaTeorica("Programación Orientada a Objetos", 4, "www.apuntesteoria.com");
        AsignaturaPractica asignatura2 = new AsignaturaPractica("Laboratorio de Redes", 3, "Guías de práctica", "Windows 10");

        AulaTeorica aula1 = new AulaTeorica("Aula 101", 101, "Edificio Norte, planta baja", 30, true, true);
        AulaLaboratorio aula2 = new AulaLaboratorio("Laboratorio de Redes", 201, "Edificio Sur, segunda planta", 20, "20 computadoras de escritorio");

        Semestre semestre1 = new Semestre(1);
        semestre1.agregarAsignatura(asignatura1);
        semestre1.agregarAsignatura(asignatura2);

        Semestre semestre2 = new Semestre(2);
        // Agregar asignaturas al semestre 2

        // Crear objeto Horario y generar horario
        Horario horario = new Horario();
        horario.agregarProfesor(profesor1);
        horario.agregarProfesor(profesor2);
        horario.agregarAula(aula1);
        horario.agregarAula(aula2);

        boolean horarioCompleto = horario.generarHorario(semestre1);

        if (horarioCompleto) {
            System.out.println("Horario generado completamente:");
            horario.mostrarHorario();
        } else {
            System.out.println("No se pudo generar el horario completo.");
        }
    }
}