public class Aula {

    //--------------------Attributes--------------------//
    private String name;
    private int numero;
    private String ubicacion;
    private int capacidad;

    //--------------------Constructor--------------------//
    public Aula(String name, int numero, String ubicacion, int capacidad) {
        this.name = name;
        this.numero = numero;
        this.ubicacion = ubicacion;
        this.capacidad = capacidad;
    }

    //--------------------Getters--------------------//

    public String getName() {
        return name;
    }

    public int getNumero() {
        return numero;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public int getCapacidad() {
        return capacidad;
    }

    //--------------------Setters--------------------//

    public void setName(String name) {
        this.name = name;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    //--------------------Methods---------------------//
    public boolean esAdecuada(Asignatura asignatura) {
        return true;
    }



    //--------------------toString--------------------//
    @Override
    public String toString() {
        return "Aula{" + "name=" + name + ", numero=" + numero + ", ubicacion=" + ubicacion + ", capacidad=" + capacidad + '}';
    }
}
