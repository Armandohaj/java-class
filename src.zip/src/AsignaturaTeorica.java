public class AsignaturaTeorica extends Asignatura{

    //--------------------Attributes--------------------//
    private String sitioWeb;

    //--------------------Constructor--------------------//
    public AsignaturaTeorica(String name, int creditos, String sitioWeb) {
        super(name, creditos);
        this.sitioWeb = sitioWeb;
    }

    //--------------------Getters--------------------//
    public String getSitioWeb() {
        return sitioWeb;
    }

    //--------------------Setters--------------------//
    public void setSitioWeb(String sitioWeb) {
        this.sitioWeb = sitioWeb;
    }

    //--------------------toString--------------------//
    @Override
    public String toString() {
        return "AsignaturaTeorica{" + "name=" + getName() + ", creditos=" + getCreditos() + ", sitioWeb=" + sitioWeb + '}';
    }



}
