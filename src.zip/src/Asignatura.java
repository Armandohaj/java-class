public class Asignatura {

    //--------------------Attributes--------------------//
    private String name;
    private int creditos;



    //--------------------Constructor--------------------//
    public Asignatura(String name, int creditos) {
        this.name = name;
        this.creditos = creditos;
    }

    //--------------------Getters--------------------//
    public String getName() {
        return name;
    }

    public int getCreditos() {
        return creditos;
    }

    //--------------------Setters--------------------//

    public void setName(String name) {
        this.name = name;
    }

    public void setCreditos(int creditos) {
        this.creditos = creditos;
    }

    //--------------------toString--------------------//
    @Override
    public String toString() {
        return "Asignatura{" + "name=" + name + ", creditos=" + creditos + '}';
    }
}
