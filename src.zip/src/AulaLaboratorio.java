public class AulaLaboratorio extends Aula{
    //--------------------Attributes--------------------//
    private String equipoTecnico;

    //--------------------Constructor--------------------//
    public AulaLaboratorio(String nombre, int numero, String ubicacion, int capacidad, String equipoTecnico) {
        super(nombre, numero, ubicacion, capacidad);
        this.equipoTecnico = equipoTecnico;
    }

    //--------------------Getters--------------------//

    public String getEquipoTecnico() {
        return equipoTecnico;
    }

    //--------------------Setters--------------------//

    public void setEquipoTecnico(String equipoTecnico) {
        this.equipoTecnico = equipoTecnico;
    }

    //--------------------toString--------------------//
    @Override
    public String toString() {
        return "AulaLaboratorio{" + "nombre=" + getName() + ", numero=" + getNumero() + ", ubicacion=" + getUbicacion() + ", capacidad=" + getCapacidad() + ", equipoTecnico=" + equipoTecnico + '}';
    }


}
