import java.util.*;

public class GeneradorHorarios {
    private List<Profesor> profesores;
    private List<Asignatura> asignaturas;
    private List<Aula> aulas;
    private List<Asignacion> asignaciones;

    public GeneradorHorarios() {
        profesores = new ArrayList<>();
        asignaturas = new ArrayList<>();
        aulas = new ArrayList<>();
        asignaciones = new ArrayList<>();
    }

    public void agregarProfesor(Profesor profesor) {
        profesores.add(profesor);
    }

    public void agregarAsignatura(Asignatura asignatura) {
        asignaturas.add(asignatura);
    }

    public void agregarAula(Aula aula) {
        aulas.add(aula);
    }

    public boolean generarHorarios(Semestre semestre) {
        asignaciones.clear(); // Limpiar asignaciones previas

        List<Asignatura> asignaturasASignar = new ArrayList<>(semestre.getAsignaturas());
        boolean horarioCompleto = true;

        while (!asignaturasASignar.isEmpty()) {
            Asignatura asignatura = asignaturasASignar.get(0);
            Profesor profesorDisponible = encontrarProfesorDisponible(asignatura);
            Aula aulaDisponible = encontrarAulaDisponible(asignatura);

            if (profesorDisponible != null && aulaDisponible != null) {
                List<Periodo> periodosDisponibles = generarPeriodosDisponibles(profesorDisponible, aulaDisponible, asignatura.getCreditos());

                if (!periodosDisponibles.isEmpty()) {
                    Asignacion nuevaAsignacion = new Asignacion(asignatura, profesorDisponible, aulaDisponible, periodosDisponibles);
                    asignaciones.add(nuevaAsignacion);
                    asignaturasASignar.remove(asignatura);
                } else {
                    horarioCompleto = false;
                    System.out.println("No se pudo asignar la asignatura: " + asignatura.getNombre());
                    asignaturasASignar.remove(asignatura);
                }
            } else {
                horarioCompleto = false;
                System.out.println("No se pudo asignar la asignatura: " + asignatura.getNombre());
                asignaturasASignar.remove(asignatura);
            }
        }

        return horarioCompleto;
    }

    private Profesor encontrarProfesorDisponible(Asignatura asignatura) {
        for (Profesor profesor : profesores) {
            if (profesor.puedeImpartir(asignatura) && !tieneConflicto(profesor, asignatura)) {
                return profesor;
            }
        }
        return null;
    }

    private Aula encontrarAulaDisponible(Asignatura asignatura) {
        for (Aula aula : aulas) {
            if (aula.esAdecuada(asignatura) && !tieneConflicto(aula, asignatura)) {
                return aula;
            }
        }
        return null;
    }

    private List<Periodo> generarPeriodosDisponibles(Profesor profesor, Aula aula, int creditos) {
        List<Periodo> periodosDisponibles = new ArrayList<>();
        Map<String, List<Periodo>> diasDisponibles = new HashMap<>();

        // Obtener los días disponibles para el profesor
        List<String> diasProfesor = profesor.getDiasDisponibles();
        for (String dia : diasProfesor) {
            diasDisponibles.put(dia, new ArrayList<>());
        }

        // Generar los periodos disponibles para cada día
        for (Map.Entry<String, List<Periodo>> entry : diasDisponibles.entrySet()) {
            String dia = entry.getKey();
            List<Periodo> periodosDelDia = generarPeriodosDelDia(dia, profesor, aula, creditos);
            entry.getValue().addAll(periodosDelDia);
        }

        // Combinar los periodos disponibles de todos los días
        for (List<Periodo> periodosDelDia : diasDisponibles.values()) {
            periodosDisponibles.addAll(periodosDelDia);
        }

        return periodosDisponibles;
    }

    private List<Periodo> generarPeriodosDelDia(String dia, Profesor profesor, Aula aula, int creditos) {
        List<Periodo> periodosDelDia = new ArrayList<>();
        int horasRequeridas = creditos * 3; // 1 crédito = 3 horas
        int horasDisponibles = 0;
        int horaInicio = 7; // 7:00 am
        int horaFin = 11; // 11:00 am

        while (horaFin <= 16) { // Hasta las 4:00 pm
            if (!tieneConflicto(profesor, dia, horaInicio, horaFin) && !tieneConflicto(aula, dia, horaInicio, horaFin)) {
                horasDisponibles += horaFin - horaInicio;
                if (horasDisponibles >= horasRequeridas) {
                    Periodo periodo = new Periodo(dia, horaInicio, horaFin);
                    periodosDelDia.add(periodo);
                    horasDisponibles = 0;
                }
            } else {
                horasDisponibles = 0;
            }

            if (horaFin == 11) {
                horaInicio = 12;
                horaFin = 16;
            } else {
                horaInicio += 4;
                horaFin += 4;
            }
        }

        return periodosDelDia;
    }

    private boolean tieneConflicto(Profesor profesor, Asignatura asignatura) {
        // Verificar si el profesor ya tiene una asignación en el mismo horario
        for (Asignacion asignacion : asignaciones) {
            if (asignacion.getProfesor() == profesor) {
                for (Periodo periodo : asignacion.getPeriodos()) {
                    int horasRequeridas = asignatura.getCreditos() * 3;
                    int horaInicio = periodo.getHoraInicio();
                    int horaFin = periodo.getHoraFin();

                    // Verificar si la nueva asignatura se solapa con la existente
                    if (periodo.getDia().equals(asignatura.getDia()) &&
                            ((horaInicio >= horaFin - horasRequeridas && horaInicio < horaFin) ||
                                    (horaFin >= horaInicio && horaFin <= horaInicio + horasRequeridas))) {
                        return true; // Hay conflicto
                    }
                }
            }
        }
        return false; // No hay conflicto
    }

    private boolean tieneConflicto(Aula aula, Asignatura asignatura) {
        // Verificar si el aula ya está asignada en el mismo horario
        for (Asignacion asignacion : asignaciones) {
            if (asignacion.getAula() == aula) {
                for (Periodo periodo : asignacion.getPeriodos()) {
                    int horasRequeridas = asignatura.getCreditos() * 3;
                    int horaInicio = periodo.getHoraInicio();
                    int horaFin = periodo.getHoraFin();

                    // Verificar si la nueva asignatura se solapa con la existente
                    if (periodo.getDia().equals(asignatura.getDia()) &&
                            ((horaInicio >= horaFin - horasRequeridas && horaInicio < horaFin) ||
                                    (horaFin >= horaInicio && horaFin <= horaInicio + horasRequeridas))) {
                        return true; // Hay conflicto
                    }
                }
            }
        }
        return false; // No hay conflicto
    }

    private boolean tieneConflicto(Profesor profesor, String dia, int horaInicio, int horaFin) {
        // Verificar si el profesor ya tiene una asignación en el mismo horario
        for (Asignacion asignacion : asignaciones) {
            if (asignacion.getProfesor() == profesor) {
                for (Periodo periodo : asignacion.getPeriodos()) {
                    // Verificar si el nuevo periodo se solapa con el existente
                    if (periodo.getDia().equals(dia) &&
                            ((horaInicio >= periodo.getHoraInicio() && horaInicio < periodo.getHoraFin()) ||
                                    (horaFin > periodo.getHoraInicio() && horaFin <= periodo.getHoraFin()))) {
                        return true; // Hay conflicto
                    }
                }
            }
        }
        return false; // No hay conflicto
    }

    private boolean tieneConflicto(Aula aula, String dia, int horaInicio, int horaFin) {
        // Verificar si el aula ya está asignada en el mismo horario
        for (Asignacion asignacion : asignaciones) {
            if (asignacion.getAula() == aula) {
                for (Periodo periodo : asignacion.getPeriodos()) {
                    // Verificar si el nuevo periodo se solapa con el existente
                    if (periodo.getDia().equals(dia) &&
                            ((horaInicio >= periodo.getHoraInicio() && horaInicio < periodo.getHoraFin()) ||
                                    (horaFin > periodo.getHoraInicio() && horaFin <= periodo.getHoraFin()))) {
                        return true; // Hay conflicto
                    }
                }
            }
        }
        return false; // No hay conflicto
    }

    public void mostrarHorarios() {
        for (Asignacion asignacion : asignaciones) {
            System.out.println("Asignatura: " + asignacion.getAsignatura().getNombre());
            System.out.println("Profesor: " + asignacion.getProfesor().getNombre());
            System.out.println("Aula: " + asignacion.getAula().getNombre());
            System.out.println("Periodos:");
            for (Periodo periodo : asignacion.getPeriodos()) {
                System.out.println("  " + periodo.getDia() + " " + periodo.getHoraInicio() + " - " + periodo.getHoraFin());
            }
            System.out.println();
        }
    }
}