public class Periodo {

    //--------------------Attributes--------------------//
    private int dia;

    private int horaInicio;

    private int horaFin;

    //--------------------Constructor--------------------//
    public Periodo(int dia, int horaInicio, int horaFin) {
        this.dia = dia;
        this.horaInicio = horaInicio;
        this.horaFin = horaFin;
    }

    //--------------------Getters--------------------//
    public int getDia() {
        return dia;
    }

    public int getHoraInicio() {
        return horaInicio;
    }

    public int getHoraFin() {
        return horaFin;
    }

    //--------------------Setters--------------------//

    public void setDia(int dia) {
        this.dia = dia;
    }

    public void setHoraInicio(int horaInicio) {
        this.horaInicio = horaInicio;
    }

    public void setHoraFin(int horaFin) {
        this.horaFin = horaFin;
    }

    //--------------------toString--------------------//
    @Override
    public String toString() {
        return "Periodo{" + "dia=" + dia + ", horaInicio=" + horaInicio + ", horaFin=" + horaFin + '}';
    }



}
