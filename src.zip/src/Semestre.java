import java.util.ArrayList;
import java.util.List;
public class Semestre {

    //--------------------Attributes--------------------//
    private int numero;

    //--------------------Constructor--------------------//
    private List<Asignatura> asignaturas = new ArrayList<>();

    public Semestre(int numero) {
        this.numero = numero;
    }


    //--------------------Getters--------------------//
    public int getNumero() {
        return numero;
    }


    //--------------------Setters--------------------//
    public void setNumero(int numero) {
        this.numero = numero;
    }

    public List<Asignatura> getAsignaturas() {
        return asignaturas;
    }

    public void setAsignaturas(List<Asignatura> asignaturas) {
        this.asignaturas = asignaturas;
    }

    public void agregarAsignatura(Asignatura asignatura) {
        asignaturas.add(asignatura);
    }

}
