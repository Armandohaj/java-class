public class Asignacion {

    //--------------------Attributes--------------------//
    private Asignatura asignatura;
    private Profesor profesor;

    private Aula aula;
    private Periodo periodo;

    //--------------------Constructor--------------------//

    public Asignacion(Asignatura asignatura, Profesor profesor, Aula aula, Periodo periodo) {
        this.asignatura = asignatura;
        this.profesor = profesor;
        this.aula = aula;
        this.periodo = periodo;
    }

    //--------------------Getters--------------------//

    public Asignatura getAsignatura() {

        return asignatura;
    }

    public Profesor getProfesor() {
        return profesor;
    }

    public Aula getAula() {
        return aula;
    }

    public Periodo getPeriodo() {
        return periodo;
    }

    //--------------------Setters--------------------//

    public void setAsignatura(Asignatura asignatura) {
        this.asignatura = asignatura;
    }

    public void setProfesor(Profesor profesor) {
        this.profesor = profesor;
    }

    public void setAula(Aula aula) {
        this.aula = aula;
    }

    public void setPeriodo(Periodo periodo) {
        this.periodo = periodo;
    }

    //--------------------toString--------------------//
    @Override
    public String toString() {
        return "Asignacion{" + "asignatura=" + asignatura + ", profesor=" + profesor + ", aula=" + aula + ", periodo=" + periodo + '}';
    }
}
