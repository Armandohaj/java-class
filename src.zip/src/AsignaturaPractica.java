public class AsignaturaPractica extends Asignatura{

    //--------------------Attributes--------------------//
    private String material;
    private String sistemaOperativo;

    //--------------------Constructor--------------------//
    public AsignaturaPractica(String name, int creditos, String material, String sistemaOperativo) {
        super(name, creditos);
        this.material = material;
        this.sistemaOperativo = sistemaOperativo;
    }

    //--------------------Getters--------------------//
    public String getMaterial() {
        return material;
    }

    public String getSistemaOperativo() {
        return sistemaOperativo;
    }

    //--------------------Setters--------------------//

    public void setMaterial(String material) {
        this.material = material;
    }

    public void setSistemaOperativo(String sistemaOperativo) {
        this.sistemaOperativo = sistemaOperativo;
    }

    //--------------------toString--------------------//
    @Override
    public String toString() {
        return "AsignaturaPractica{" + "name=" + getName() + ", creditos=" + getCreditos() + ", material=" + material + ", sistemaOperativo=" + sistemaOperativo + '}';
    }
}
