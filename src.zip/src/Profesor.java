public class Profesor {

        //--------------------Attributes--------------------//
        private String name;
        private String cedula;
        private String horario;
        private String departamento;

        //--------------------Constructor--------------------//
        public Profesor(String name, String cedula, String horario, String departamento) {
            this.name = name;
            this.cedula = cedula;
            this.horario = horario;
            this.departamento = departamento;
        }

        //--------------------Getters--------------------//
        public String getName() {
            return name;
        }
        public String getCedula() {
            return cedula;
        }
        public String getHorario() {
            return horario;
        }
        public String getDepartamento() {
            return departamento;
        }

        //--------------------Setters--------------------//

        public void setName(String name) {
            this.name = name;
        }
        public void setCedula(String cedula) {
            this.cedula = cedula;
        }
        public void setHorario(String horario) {
            this.horario = horario;
        }
        public void setDepartamento(String departamento) {
            this.departamento = departamento;
        }

        //--------------------Methods---------------------//
        public boolean puedeImpartir(Asignatura asignatura){
            return true;
        }
        //--------------------toString--------------------//
        @Override
        public String toString() {
            return "Profesor{" + "name=" + name + ", cedula=" + cedula + ", horario=" + horario + ", departamento=" + departamento + '}';
        }




}