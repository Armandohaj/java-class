public class AulaTeorica extends Aula {

    //--------------------Attributes--------------------//
    private boolean aireAcondicionado;
    private boolean equipoMultimedia;


    //--------------------Constructor--------------------//
    public AulaTeorica(String nombre, int numero, String ubicacion, int capacidad, boolean aireAcondicionado, boolean equipoMultimedia) {
        super(nombre, numero, ubicacion, capacidad);
        this.aireAcondicionado = aireAcondicionado;
        this.equipoMultimedia = equipoMultimedia;
    }

    //--------------------Getters--------------------//

    public boolean isAireAcondicionado() {
        return aireAcondicionado;
    }

    public boolean isEquipoMultimedia() {
        return equipoMultimedia;
    }

    //--------------------Setters--------------------//

    public void setAireAcondicionado(boolean aireAcondicionado) {
        this.aireAcondicionado = aireAcondicionado;
    }

    public void setEquipoMultimedia(boolean equipoMultimedia) {
        this.equipoMultimedia = equipoMultimedia;
    }

    //--------------------toString--------------------//
    @Override
    public String toString() {
        return "AulaTeoria{" + "nombre=" + getName() + ", numero=" + getNumero() + ", ubicacion=" + getUbicacion() + ", capacidad=" + getCapacidad() + ", aireAcondicionado=" + aireAcondicionado + ", equipoMultimedia=" + equipoMultimedia + '}';
    }

}
