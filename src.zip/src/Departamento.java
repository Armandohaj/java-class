public class Departamento {

    //--------------------Attributes--------------------//
    private String name;

    //--------------------Constructor--------------------//
    public Departamento(String name) {
        this.name = name;
    }

    //--------------------Getters--------------------//
    public String getName() {
        return name;
    }

    //--------------------Setters--------------------//
    public void setName(String name) {
        this.name = name;
    }

    //--------------------toString--------------------//
    @Override
    public String toString() {
        return "Departamento{" + "name=" + name + '}';
    }

}
